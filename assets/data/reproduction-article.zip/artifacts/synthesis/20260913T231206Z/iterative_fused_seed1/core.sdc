create_clock -name clk -period 20.000 [get_ports {clk}]
derive_clock_uncertainty
set_input_delay -clock clk 2.000 [get_ports {instruction[*]}]
set_output_delay -clock clk 2.000 [get_ports {address[*] result_a[*]}]
set_false_path -from [get_ports {rst}]
